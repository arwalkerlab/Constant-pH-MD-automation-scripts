import argparse

parser = argparse.ArgumentParser(description="A script that accepts keyword arguments.")
parser.add_argument('--pdb', type=str, help='The pdb of the protein.')
parser.add_argument('--pH', type=int, help='The pH of the simulation.')

args = parser.parse_args()
pdb = args.pdb
pH = str(args.pH)


def pdb_name(string):
    indx1 = string.find(".pdb")
    return string[:indx1]


def write_production_script(pdb,pH,**kwargs):
    defaults = {"time": "200:00:00",
            "job_name": "CpH_md",
            "nodes": 3,
            "memory": "10GB"
    }
    inputs = {**defaults, **kwargs}
    with open("production.sh", "x") as file:
        #
        file.write(f"#!/bin/bash\n#SBATCH -t {inputs['time']}\n#SBATCH --job-name {inputs['job_name']}\n#SBATCH -q express\n\
#SBATCH --nodelist=arw1,arw2,arw3\n#SBATCH -N 1\n#SBATCH -n {inputs['nodes']}\n#SBATCH --gres=gpu:1\n\
#SBATCH --mem={inputs['memory']}\n")
        #
        file.write(f"\npH={pH}\n\ne=0\nf=1\nwhile [ $f -lt 101 ]; do\n\n")
        #
        name = pdb_name(pdb)
        #
        output = name + "_md$f.mdout"
        parmtop = name + "_mod.prmtop"
        checkpoint = name + "_md$e.rst7"
        restart = name + "_md$f.rst7"
        trajectory = name + "_md$f.nc"
        reference = name + "_md$e.rst7"
        cpin = name + "_md$e.cpin"
        cpout = name + "_md$f.cpout"
        cprestart = name + "_md$f.cpin"
        #
        #
        file.write(f"pmemd.cuda -O -i template.mdin \\\n-o {output} \\\n-p {parmtop} \\\n-c {checkpoint} \\\n\
-r {restart} \\\n-x {trajectory} \\\n-ref {reference} \\\n-cpin {cpin} \\\n-cpout {cpout} \\\n\
-cprestrt {cprestart}\n")
        #
        file.write(f"\ne=$[$e+1]\nf=$[$f+1]\ndone\n")
        for i in range(90,101):
            cpout = name + f"_md{i}.cpout"
            calcpka = name + f"_pH{pH}_{i}ns_calcpka.dat"
            population = name + f"_pH{pH}_{i}ns_populations.dat"
            file.write(f"\ncphstats -i {cpin} {cpout} -o {calcpka} --population {population}\n")
        file.write(f"cp *_calcpka.dat ../analysis\n")
        file.close


write_production_script(pdb, pH)