#!/usr/bin/env python3
import argparse

parser = argparse.ArgumentParser(description="A script that accepts keyword arguments.")
parser.add_argument('--pH_initial', type=int, help='The initial pH of the simulation.')
parser.add_argument('--pH_final', type=int, help='The final pH of the simulation.')

args = parser.parse_args()
pH_min = args.pH_initial #lower limit of the x-axis
pH_max = args.pH_final #upper limit of the x-axis

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as tck
import matplotlib.cm as cm
import os
import subprocess
from scipy.ndimage import gaussian_filter
from scipy.stats import kde
from scipy.optimize import curve_fit
import numpy as np

pH_min = 0 #lower limit of the x-axis
pH_max = 9 #upper limit of the x-axis


def pH_in_list(input_list,pH):
    pH_found = 0
    for i in input_list:
        current_pH = i["Solvent pH"]
        if pH == current_pH:
            pH_found = True
            break
        else: 
            pH_found = False
    return pH_found

def analyze_pKa(pH_data,input_list):
    pH_data = open(pH_data, "r").readlines()
    split_list = pH_data[0].split() #the first line contains the solvent pH parameter
    solvent_pH = float(split_list[3]) #pH of the currently open file 
    
    
    if pH_in_list(input_list, solvent_pH) == True: #if pH is in the data list, data will be added to existing entry
        for i in input_list:
            if solvent_pH == i["Solvent pH"]:
                for a in pH_data[1:-2]:
                    line_split = a.split()
                    if int(line_split[1]) > 65:
                        res_num = int(line_split[1]) + 2
                        residue = line_split[0] + " " + str(res_num)
                    else:
                        residue = line_split[0] + " " + line_split[1]
                    if residue == i["Residue"]:
                        fraction_protonated = float(line_split[9]) #The fraction of the time the residue was protonated
                        transitions = int(line_split[-1]) #The number of protonation state transitions during simulation
                        i["Transitions"] = int(i["Transitions"]) + transitions
                        i["Sum Fraction Protonated"] = round((float(i["Sum Fraction Protonated"]) + fraction_protonated),3)
                        i["Residue Count"] = int(i["Residue Count"])+1

    
    else:
        for a in pH_data[1:-2]: #the last three lines are blank, hence the index [1:-2]
            line_split = a.split() #Splits the line "a" into a list based on whitespace characters
        
            if line_split[4] != "inf" and "-inf": #used to ignore any residues where transitions did not occur
                if int(line_split[1]) > 65:
                    res_num = int(line_split[1]) + 2
                    residue = line_split[0] + " " + str(res_num)
                else:
                    residue = line_split[0] + " " + line_split[1] #Combines the residue name and number
                predicted_pKa = float(line_split[6]) #pKa predicted by CPH-MD
                fraction_protonated = float(line_split[9]) #The fraction of the time the residue was protonated
                transitions = line_split[-1] #The number of protonation state transitions during simulation
                res_count = 1
                pH_data_dict={"Solvent pH":solvent_pH,"Residue":residue,"Predicted pKa":predicted_pKa,
                   "Transitions":transitions,"Sum Fraction Protonated":fraction_protonated,
                    "Residue Count":res_count
                   }
                input_list.append(pH_data_dict) #Adds dictionary to list

### float_range - this function generates a list of x values between pH_min and pH_max with an interval of 0.01, ###
### this is used with the coefficients from the curve_fit funtion to obtain a smooth titration curve. ###
def float_range(pH_min, pH_max):
    float_list = [] #This is the list that will contain the range of x-values
    for i in np.arange(pH_min,pH_max+0.01,0.01): #by default pH_max is not included in the resulting list, 0.01 must be added
        i = round(i, 3) #Due to float math some numbers may have residual artifacts that are removed by round() ex.0.50000007
        float_list.append(i) #adds "i" to float_list
    return float_list #returns the list of x-values

### f - this function is for the titration curve and curve fitting ###
def f(x,n,pka):
    result = 1 / (1 + 10**(n*(pka - x))) #where x is the pH
    return result



### plot_titration_curve - this funtion generates a titration curve for a given residue, uncomment last few lines to save images ###
def plot_titration_curve(residue, pH_data, frac_deprotonated_data):
    #keyword arguements 
        #residue - string that determines the name of the titration curve
        #pH_data -  list of pH values that the constant pH md was run at, not from float_list
        #frac_deprotonated_data - list of corresponding deprotonation fractions 

    #creates the plot for the residue
    titration_curves = plt.figure(figsize=[6,4.5],dpi=150)
    axs = titration_curves.add_subplot(2,2,1)

    #The following two lines will determine the coefficient's from curve fitting and
    #create a range of x-values for the best-fit curve
    array_fit, fit = curve_fit(f,pH_data,frac_deprotonated_data, bounds=(0, [1., 10.]))
    pH_sequence = float_range(pH_min,pH_max) 

    #The following line plots the actual data points from the constant pH md as a red "+" mark
    axs.scatter(pH_data, frac_deprotonated_data, color="red", marker = "+", lw=0.5)
    
    #The following two lines plots the best-fit curve as a green line
    axs.plot(pH_sequence, f(pH_sequence, *array_fit), 'g-', lw=0.5,
        label='fit: n=%5.3f, pKa=%5.3f' % tuple(array_fit))    

    #The following section formats the plot
    axs.legend(loc=2,fontsize=5) 
    axs.set_aspect('auto')
    axs.set_xlim(pH_min,pH_max)
    axs.set_ylim(0,1)
    axs.xaxis.set_major_locator(tck.MultipleLocator(1))
    axs.yaxis.set_major_locator(tck.MultipleLocator(0.2))
    axs.set_xlabel("pH",fontsize=8)
    axs.set_ylabel("Fraction Deprotonated",fontsize=8)
    axs.set_title(str(residue),fontsize=8)
    axs.tick_params(labelsize=8)


    #### uncomment the following lines to have the notebook save the plot to an image file ##### 
    file_name = residue + " titration curve"
    plt.savefig(file_name, bbox_inches="tight", pad_inches=0.3, transparent=True)

    
    return axs #returns the plot
    
    


#Directory Search - searches working directory for files containing the string "calcpka" which corresponds to the CPH-MD data files
input_list = []
directory_files = os.listdir() # Will make a list of files in working directory
for x in directory_files: # Iterates through each file in the directory
    if "calcpka" in x: # determines if the file name contains the string "calcpka"
        analyze_pKa(x,input_list); # analyzes data contained in file


data_list = []
for i in input_list:
    solvent_pH = i["Solvent pH"]
    residue = i["Residue"]
    predicted_pKa = i["Predicted pKa"]
    transitions = i["Transitions"]
    avg_fraction_protonated = i["Sum Fraction Protonated"] / i["Residue Count"]
    fraction_protonated = round(avg_fraction_protonated,3)
    fraction_deprotonated = round(1-fraction_protonated,3)
    
    
    pH_data_dict={"Solvent pH":solvent_pH,"Residue":residue,"Predicted pKa":predicted_pKa,
        "Transitions":transitions,"Fraction Protonated":fraction_protonated,"Fraction Deprotonated":fraction_deprotonated,
        }
    data_list.append(pH_data_dict) #Adds dictionary to list

# data frame to store data from the analyzed files
df = pd.DataFrame(columns=["Solvent pH","Residue","Predicted pKa",
               "Transitions","Fraction Protonated","Fraction Deprotonated"])


# adds list of data to data frame and sorts it, uncomment final section to save to excel file
df = pd.concat([df, pd.DataFrame(data_list)])        

# following section formats the numerical columns
df["Solvent pH"] = df["Solvent pH"].apply(lambda x: str(float(x)) if isinstance(x, (int, float)) else x)
df["Predicted pKa"] = df["Predicted pKa"].apply(lambda x: str(float(x)) if isinstance(x, (int, float)) else x)
df["Fraction Protonated"] = df["Fraction Protonated"].apply(lambda x: str(float(x)) if isinstance(x, (int, float)) else x)
df["Fraction Deprotonated"] = df["Fraction Deprotonated"].apply(lambda x: str(float(x)) if isinstance(x, (int, float)) else x)

# sorts the data frame by residue followed by the pH
df = df.sort_values(["Residue","Solvent pH"],ascending=[True,True]).round(3)

# formats the data frame
df2 = df.style.set_table_styles([dict(selector='th', props=[('text-align', 'center')])])
df2.set_properties(**{'text-align': 'center'})  

#### uncomment following line to export data to an excel file ####
#df2.to_excel("residue_pH_data.xlsx")


# exports residue names and corresponding pKa to lists

#the following section contain key lists that values will be added to
res_list = []
pKa_list = []
pH_lists = []
frac_deprot_lists = []


for x in range(len(df)): # iterates through each line of dataframe
    if  df['Residue'].iloc[x] not in res_list: # true if current residue is not in dataframe
        res_list.append(df['Residue'].iloc[x]) # adds residue to res_list
        pKa_list.append(df['Predicted pKa'].iloc[x]) # adds corresponding pKa to pKa_list


# iterates through dataframe to store pH data and corresponding deprotonation fractions for each residue
for i in res_list: # will iterate through each unique residue in res_list
    # the following lists are set blank when iteration reaches a new residue 
    res_pH_list = [] 
    res_frac_deprot_list = []
    for x in range(len(df)): # iterates through each line of the dataframe
        current_res = df['Residue'].iloc[x] # determines the identity of residue of the current line of the dataframe
        if current_res == i: # true if the identity of the residue of the dataframe matches that of "i" in res_list
            pH = float(df['Solvent pH'].iloc[x]) # determines pH simulation was performed at
            frac_deprot = float(df['Fraction Deprotonated'].iloc[x]) # determines the corresponding deprotonation fraction

            # the following section appends data to a list
            res_pH_list.append(pH) 
            res_frac_deprot_list.append(frac_deprot)
    
    # once all of the data for a given residue is in a list it is appended to pH_lists and frac_deprot_lists
    # giving a parent list with nested lists of data for each residue
    pH_lists.append(res_pH_list)
    frac_deprot_lists.append(res_frac_deprot_list)  

# creates a plot for each unique residue from "res_list"
for i in range(len(res_list)):
    plot_titration_curve(res_list[i], pH_lists[i], frac_deprot_lists[i])