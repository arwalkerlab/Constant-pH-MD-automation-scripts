#loading argparse library to accept command line arguments from bash
import argparse
#This script takes the name of the pdb file to generate a shell script to run equilibration on a system 
parser = argparse.ArgumentParser(description="A script that accepts keyword arguments.")
parser.add_argument('--pdb', type=str, help='The pdb of the protein.')

args = parser.parse_args()
pdb = args.pdb

#This function extracts the filename of the pdb file
def pdb_name(string):
    indx1 = string.find(".pdb") #finds the position of the file format ".pdb" in the file name
    return string[:indx1] #returns the file name minus ".pdb"

#The following function writes a shell script to perform equilibration
def write_equilibriation_script(pdb,**kwargs):
    defaults = {"time": "10:00:00",
            "job_name": "CpH_md",
            "nodes": 3,
            "memory": "5GB"
    }
    inputs = {**defaults, **kwargs}
    with open("equilibriation.sh", "x") as file:
        #
        file.write(f"#!/bin/bash\n#SBATCH -t {inputs['time']}\n#SBATCH --job-name {inputs['job_name']}\n#SBATCH -q express\n\
#SBATCH --nodelist=arw1,arw2,arw3\n#SBATCH -N 1\n#SBATCH -n {inputs['nodes']}\n#SBATCH --gres=gpu:1\n\
#SBATCH --mem={inputs['memory']}\n")
        #
        file.write(f"\ne=0\nf=1\nwhile [ $f -lt 13 ]; do\n\n")
        #
        name = pdb_name(pdb)
        #
        output = name + "_init$f.mdout"
        parmtop = name + "_mod.prmtop"
        checkpoint = name + "_init$e.rst7"
        restart = name + "_init$f.rst7"
        trajectory = name + "_init$f.nc"
        reference = name + "_init$e.rst7"
        cpin = name + "_init$e.cpin"
        cpout = name + "_init$f.cpout"
        cprestart = name + "_init$f.cpin"
        #
        #
        file.write(f"pmemd.cuda -O -i mdin.$f \\\n-o {output} \\\n-p {parmtop} \\\n-c {checkpoint} \\\n\
-r {restart} \\\n-x {trajectory} \\\n-ref {reference} \\\n-cpin {cpin} \\\n-cpout {cpout} \\\n\
-cprestrt {cprestart}\n")
        #
        file.write(f"\ne=$[$e+1]\nf=$[$f+1]\n")
        
        file.write(f"done\n\n")
        #
        md_cpin = name + "_md0.cpin"
        equil_cpin = name + "_init0.cpin"
        file.write(f"mv {equil_cpin} {md_cpin}\ncp {md_cpin} ..\n")
        #
        md_rst7 = name + "_md0.rst7"
        equil_rst7 = name + "_init12.rst7"
        file.write(f"mv {equil_rst7} {md_rst7}\ncp {md_rst7} ..\n")
        file.close

write_equilibriation_script(pdb)