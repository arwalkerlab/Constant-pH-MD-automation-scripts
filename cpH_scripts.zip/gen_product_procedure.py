import argparse

parser = argparse.ArgumentParser(description="A script that accepts keyword arguments.")
parser.add_argument('--pH', type=int, help='The pH of the simulation.')

args = parser.parse_args()
pH = args.pH


def production_procedure(pH):
    with open("template.mdin", "x") as mdin:
        #
        mdin.write(f"Explicit solvent constant pH MD\n\
 &cntrl\n   imin=0, irest=1, ntx=5, ntxo=2,\n\
   ntpr=1000, ntwx=1000, nstlim=1000000,\n\
   dt=0.002, ntt=3, tempi=300,\n\
   temp0=300, gamma_ln=5.0, ig=-1,\n\
   ntc=2, ntf=2, cut=10, iwrap=1,\n\
   ioutfm=1, icnstph=2, ntcnstph=100,\n\
   solvph={pH}, ntrelax=100, saltcon=0.1,\n /\n")

production_procedure(pH)