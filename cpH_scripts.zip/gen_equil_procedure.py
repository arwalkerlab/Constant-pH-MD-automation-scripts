def equilibration_procedure():
    with open("mdin.1", "x") as mdin1:
        #
        mdin1.write(f"LPO\n &cntrl\n  imin   = 1,\n  maxcyc = 5000,\n\
  ncyc   = 500,\n  ntc = 2, ntf = 1,  iwrap = 1,\n  ntb    = 1,\n\
  ntr    = 1,\n  cut    = 10,\n   /\nHold protein fixed\n0.0\n\
RES 1 69\n0.0\nRES 71 139\n0.0\nRES 70 70\nEND\nEND\n")
        mdin1.close
        #
    with open("mdin.2", "x") as mdin2:
        #
        mdin2.write(f"LPO\n &cntrl\n  ntx=1,        irest=0,\n\
  ntpr=5,       ntwx=100,     ntwv=00,\n\
  nstlim=1000,   t=0.00,        dt=0.00100,\n\
  ntc = 2, ntf = 1,\n  iwrap = 1,\n  ig=-1\n\
  ntt=1, temp0=010.0, tempi=010.0, tautp=0.5,\n  ntr    = 1,\n\
  cut    = 08.0,\n /\nHold protein fixed\n250.0\nRES 1 69\n\
250.0\nRES 71 139\n250.0\nRES 70 70\nEND\nEND\n")
        mdin2.close
        #
    with open("mdin.3", "x") as mdin3:
        #
        mdin3.write(f"LPO\n &cntrl\n  ntx=7,        irest=1,\n\
  ntpr=5,       ntwx=100,     ntwv=00,\n\
  nstlim=10000,   t=0.00,        dt=0.00100,\n\
  ntc = 2, ntf = 1,\n  ntb    = 2, ntp=2,\n  iwrap = 1,\n\
  ig=-1\n  ntt=1, temp0=010.0, tempi=010.0, tautp=0.5,\n\
  ntr    = 1,\n  cut    = 08.0,\n /\nHold protein fixed\n\
100.0\nRES 1 69\n100.0\nRES 71 139\n100.0\nRES 70 70\n\
END\nEND\n")
        mdin3.close
        #
    with open("mdin.4", "x") as mdin4:
        #
        mdin4.write(f"LPO\n &cntrl\n  ntx=7,        irest=1,\n\
  nsnb=1,\n  ntpr=5,       ntwx=100,     ntwv=00,\n\
  nstlim=10000,   t=0.00,        dt=0.00100,\n\
  ntc = 2, ntf = 1,\n  ntb    = 2, ntp=2,\n\
  iwrap = 1,\n  ntt=1, temp0=010.0, tempi=010.0, tautp=0.5,\n\
  ntr    = 1,\n  cut    = 08.0,\n /\nHold protein fixed\n\
50.0\nRES 1 69\n50.0\nRES 71 139\n50.0\nRES 70 70\n\
END\nEND\n")
        mdin4.close
        #
    with open("mdin.5", "x") as mdin5:
        #
        mdin5.write(f"LPO\n &cntrl\n  ntx=7,        irest=1,\n\
  nsnb=1,\n  ntpr=5,       ntwx=100,     ntwv=00,\n\
  nstlim=10000,   t=0.00,        dt=0.00100,\n\
  ntc = 2, ntf = 1,\n  ntb    = 2, ntp=2,\n  iwrap = 1,\n\
  ntt=1, temp0=010.0, tempi=010.0, tautp=0.5,\n  ntr    = 1,\n\
  cut    = 08.0,\n /\nHold protein fixed\n0.0\nRES 1 69\n\
0.0\nRES 71 139\n25.0\nRES 70 70\nEND\nEND\n")
        mdin5.close
        #
    with open("mdin.6", "x") as mdin6:
        #
        mdin6.write(f"LPO Constant volume  constraints on protein + HEME\n\
 &cntrl\n  ntx=7,        irest=1,\n  nsnb=1,\n\
  ntpr=100,       ntwx=1000,     ntwv=00,\n\
  nstlim=100000,   t=0.00,        dt=0.00100,\n\
  ntc = 2, ntf = 1,\n  ntb    = 1,\n  iwrap = 1,\n\
  ntt=1, temp0=010.0, tempi=010.0, tautp=0.001, vlimit=-1.0,\n\
  ntr    = 1,\n  cut    = 08.0,\n  nmropt=1\n /\n\
 &wt type='TEMP0', istep1=00000, istep2=05000, value1=000., value2=010.,  &end\n\
 &wt type='TEMP0', istep1=05001, istep2=10000, value1=010., value2=020.,  &end\n\
 &wt type='TEMP0', istep1=10001, istep2=20000, value1=020., value2=050.,  &end\n\
 &wt type='TEMP0', istep1=20001, istep2=30000, value1=050., value2=100.,  &end\n\
 &wt type='TEMP0', istep1=30001, istep2=40000, value1=100., value2=150.,  &end\n\
 &wt type='TEMP0', istep1=40001, istep2=50000, value1=150., value2=200.,  &end\n\
 &wt type='TEMP0', istep1=50001, istep2=60000, value1=200., value2=250.,  &end\n\
 &wt type='TEMP0', istep1=60001, istep2=70000, value1=250., value2=300.,  &end\n\
 &wt type='TEMP0', istep1=70001, istep2=80000, value1=300., value2=325.,  &end\n\
 &wt type='TEMP0', istep1=80001,istep2=100000, value1=325., value2=300.,  &end\n\
 &wt type='END'  &end\nHold protein fixed\n500.0\nRES 1 69\n500.0\n\
RES 71 139\n500.0\nRES 70 70\nEND\nEND\n")
        mdin6.close
        #
    with open("mdin.7", "x") as mdin7:
        #
        mdin7.write(f"LPO Constant volume  constraints on protein + heme\n\
 &cntrl\n  ntx=7, irest=1,\n  nsnb=1,\n  ntpr=10000, ntwx=1000, ntwv=0,\n\
  nstlim=10000, t=0.00, dt=0.00100,\n  ntc = 2, ntf = 1,\n  iwrap = 1,\n\
  ntb    = 2, ntp=2, \
  ntt=3, temp0=300.0, tempi=300.0, tautp=1.0, gamma_ln=5.0,\n\
  ntr    = 1,\n  cut    = 8.0,\n  vlimit=-1,\n /\nHold protein fixed\n\
500.0\nRES 1 69\n500.0\nRES 71 139\n500.0\nRES 70 70\nEND\nEND\n")
        mdin7.close
        #
    with open("mdin.8", "x") as mdin8:
        #
        mdin8.write(f"LPO Constant volume  constraints on protein + heme\n\
 &cntrl\n  ntx=7, irest=1,\n  nsnb=1,\n  ntpr=10000, ntwx=1000, ntwv=0,\n\
  nstlim=10000, t=0.00, dt=0.00100,\n  ntc = 2, ntf = 1,\n\
  iwrap = 1,\n  ntb    = 2, ntp=2,\n\
  ntt=3, temp0=300.0, tempi=300.0, tautp=1.0, gamma_ln=5.0,\n\
  ntr    = 1,\n  cut    = 8.0,\n  vlimit=-1,\n /\n\
Hold protein fixed\n250.0\nRES 1 69\n250.0\nRES 71 139\n\
250.0\nRES 70 70\nEND\nEND\n")
        mdin8.close
        #
    with open("mdin.9", "x") as mdin9:
        #
        mdin9.write(f"LPO Constant volume  constraints on protein + heme\n\
 &cntrl\n  ntx=7, irest=1,\n  nsnb=1,\n  ntpr=10000, ntwx=1000, ntwv=0,\n\
  nstlim=10000, t=0.00, dt=0.00100,\n  ntc = 2, ntf = 1,\n\
  iwrap = 1,\n  ntb    = 2, ntp=2,\n\
  ntt=3, temp0=300.0, tempi=300.0, tautp=1.0, gamma_ln=5.0,\n\
  ntr    = 1,\n  cut    = 8.0\n  vlimit=-1,\n /\n\
Hold protein fixed\n100.0\nRES 1 69\n100.0\nRES 71 139\n\
100.0\nRES 70 70\nEND\nEND\n")
        mdin9.close
        #
    with open("mdin.10", "x") as mdin10:
        #
        mdin10.write(f"LPO Constant volume  constraints on protein + heme\n\
 &cntrl\n  ntx=7, irest=1,\n  nsnb=1,\n  ntpr=10000, ntwx=1000, ntwv=0,\n\
  nstlim=10000, t=0.00, dt=0.00100,\n  ntc = 2, ntf = 1,\n\
  iwrap = 1,\n  ntb    = 2, ntp=2,\n \
  ntt=3, temp0=300.0, tempi=300.0, tautp=1.0, gamma_ln=5.0,\n\
  ntr    = 1,\n  cut    = 8.0,\n  vlimit=-1,\n /\n\
Hold protein fixed\n0.0\nRES 1 69\n0.0\nRES 71 139\n50.0\n\
RES 70 70\nEND\nEND\n")
        mdin10.close
        #
    with open("mdin.11", "x") as mdin11:
        #
        mdin11.write(f"LPO Constant volume  constraints on protein + heme\n\
 &cntrl\n  ntx=7,        irest=1,\n  nsnb=1,\n\
  ntpr=100,       ntwx=1000,     ntwv=00,\n\
  nstlim=10000,   t=0.00,        dt=0.00100,\n\
  ntc = 2, ntf = 1,\n  ntb    = 2,  ntp=2,\n  iwrap = 1,\n\
  ntt=3, temp0=300.0, tempi=300.0, tautp=1.0, vlimit=-1.0,\n\
  gamma_ln=5.0,\n  ntr    = 1,\n  cut    = 08.0,\n /\n\
Hold protein fixed\n0.0\nRES 1 69\n0.0\nRES 71 139\n\
10.0\nRES 70 70\nEND\nEND\n")
        mdin11.close
        #
    with open("mdin.12", "x") as mdin12:
        #
        mdin12.write(f"LPO Constant volume  constraints on protein + heme\n\
 &cntrl\n  ntx=7,        irest=1,\n  nsnb=1,\n\
  ntpr=100,       ntwx=1000,     ntwv=00,\n\
  nstlim=10000,   t=0.00,        dt=0.00100,\n\
  ntc = 2, ntf = 1,\n  ntb    = 2, ntp=2,\n  iwrap = 1,\n\
  ntt=1, temp0=300.0, tempi=300.0, tautp=1.0, vlimit=-1.0,\n\
  ntr    = 1,\n  cut    = 08.0,\n /\n\
Hold protein fixed\n0.0\nRES 1 69\n0.0\nRES 71 139\n\
10.0\nRES 70 70\nEND\nEND\n")
        mdin12.close


equilibration_procedure()


