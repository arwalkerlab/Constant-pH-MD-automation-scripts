#!/bin/bash
#SBATCH -t 200:00:00
#SBATCH --job-name CpH
#SBATCH -q express
#SBATCH --nodelist=arw1,arw2,arw3
#SBATCH -N 1
#SBATCH -n 3
#SBATCH --gres=gpu:1
#SBATCH --mem=10GB

#enter name of pdb below
pdb=MyFile.pdb

#enter starting pH below

pH_initial=4

#enter final pH below

pH_final=9

#enter pH interval for md simulations below (i.e. 0.5, to go from 1.0 to 1.5 to 2.0, etc.)

pH_interval=0.5





#### No edits needed below this part #### 

mkdir equilibration

prmtop=$(find . -name "*_mod.prmtop")
restart=$(find . -name "*_init0.rst7")
cpin=$(find . -name "*_init0.cpin")
pdb_file=$(find . -name "*.pdb")

cp $prmtop equilibration/
cp $restart equilibration/
cp $cpin equilibration/
cp $pdb_file equilibration/

cd equilibration
python gen_equil_script.py --pdb $pdb
python gen_equil_procedure.py
sh equilibration.sh

cd ..



# create NEW, EMPTY JobDependencies.txt
JOB_DEP_FILE=$($PWD/job_dependencies.txt)

touch $JOB_DEP_FILE

echo "" > $JOB_DEP_FILE


pH_current = $pH_initial

mkdir analysis/

md_restart=$(find . -name "*_md0.rst7")
md_cpin=$(find . -name "*_md0.cpin")

while [ $pH_current -lt $pH_final ]; do

mkdir md_pH$pH_current/

cp $prmtop md_pH$pH_current/
cp $md_restart md_pH$pH_current/
cp $md_cpin md_pH$pH_current/
cp $pdb_file md_pH$pH_current/


cd md$pH_current/
python gen_product_script.py --pdb $pdb --pH $pH_current
python gen_product_procedure.py --pH $pH_current

JOBID=$(sbatch production.sh | awk '{print $NF}')
echo $JOBID >> $JOB_DEP_FILE

cd ..

pH_current=$pH_current+$pH_interval 

done

cd analysis

JOB_IDS=$(tr '\n' ':' < $JOB_DEP_FILE | sed 's/:$//')

python gen_analysis_script.py --pH_initial $pH_initial --pH_final $pH_final

sbatch --dependency=afterok:$JOB_IDS analysis.sh


