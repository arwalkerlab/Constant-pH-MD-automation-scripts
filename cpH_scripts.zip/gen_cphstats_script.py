import argparse

parser = argparse.ArgumentParser(description="A script that accepts keyword arguments.")
parser.add_argument('--pdb', type=str, help='The pdb of the protein.')
parser.add_argument('--pH', type=str, help='The pH of the simulation.')

args = parser.parse_args()
pdb = args.pdb
pH = args.pH

def pdb_name(string):
    indx1 = string.find(".pdb")
    return string[:indx1]

def write_analysis_script(pdb,pH,**kwargs):
    defaults = {"time": "5:00:00",
            "job_name": "CpH_md",
            "nodes": 3,
            "memory": "5GB"
    }
    inputs = {**defaults, **kwargs}
    with open("cphstats.sh", "x") as file:
        #
        file.write(f"#!/bin/bash\n#SBATCH -t {inputs['time']}\n#SBATCH --job-name {inputs['job_name']}\n#SBATCH -q express\n\
#SBATCH --nodelist=arw1,arw2,arw3\n#SBATCH -N 1\n#SBATCH -n {inputs['nodes']}\n#SBATCH --gres=gpu:1\n\
#SBATCH --mem={inputs['memory']}\n")
        #
        file.write(f"\npH={pH}\n\nmodule load amber/20\n\n")
        #
        name = pdb_name(pdb)
        #
        cpin = name + "_md0.cpin"
        for i in range(90,101):
            cpout = name + f"_md{i}.cpout"
            calcpka = name + f"_pH{pH}_{i}ns_calcpka.dat"
            population = name + f"_pH{pH}_{i}ns_populations.dat"
            file.write(f"cphstats -i {cpin} {cpout} -o {calcpka} --population {population}\n")
        #
        file.write(f"done\n")
        #
        file.close

write_analysis_script("phluorin2.pdb", pH)