import argparse

parser = argparse.ArgumentParser(description="A script that accepts keyword arguments.")
parser.add_argument('--pH_initial', type=int, help='The initial pH of the protein.')
parser.add_argument('--pH_final', type=int, help='The final pH of the simulation.')

args = parser.parse_args()
pH_initial = args.pH_initial
pH_final = args.pH_final

def write_analysis_script(pH_initial,pH_final,**kwargs):
    defaults = {"time": "200:00:00",
            "job_name": "CpH_md",
            "nodes": 3,
            "memory": "10GB"
    }
    inputs = {**defaults, **kwargs}
    with open("analysis.sh", "x") as file:
        #
        file.write(f"#!/bin/bash\n#SBATCH -t {inputs['time']}\n#SBATCH --job-name {inputs['job_name']}\n#SBATCH -q express\n\
#SBATCH --nodelist=arw1,arw2,arw3\n#SBATCH -N 1\n#SBATCH -n {inputs['nodes']}\n#SBATCH --gres=gpu:1\n\
#SBATCH --mem={inputs['memory']}\n")
        #
        file.write(f"/npH_initial={pH_initial}\npH_final={pH_final}\npython titration_curve_analysis.py\
--pH_initial $pH_initial --pH_final $pH_final")
        #
        file.close

write_analysis_script(pH_initial,pH_final)